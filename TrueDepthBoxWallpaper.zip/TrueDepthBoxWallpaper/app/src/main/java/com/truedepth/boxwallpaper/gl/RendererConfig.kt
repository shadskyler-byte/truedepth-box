package com.truedepth.boxwallpaper.gl

import android.content.SharedPreferences
import com.truedepth.boxwallpaper.Prefs

data class RendererConfig(
    val motionStrength: Float,
    val smoothingSeconds: Float,
    val boxDepthScale: Float,
    val targetFps: Int,
    val glassEnabled: Boolean,
    val glowEnabled: Boolean
) {
    companion object {
        fun from(prefs: SharedPreferences): RendererConfig {
            val motion = prefs.getInt(Prefs.MOTION_STRENGTH, 100).coerceIn(0, 160) / 100f
            val smoothRaw = prefs.getInt(Prefs.SMOOTHING, 42).coerceIn(0, 100)
            val smoothing = 0.025f + (smoothRaw / 100f) * 0.34f
            val depth = prefs.getInt(Prefs.BOX_DEPTH, 100).coerceIn(60, 160) / 100f
            return RendererConfig(
                motionStrength = motion,
                smoothingSeconds = smoothing,
                boxDepthScale = depth,
                targetFps = if (prefs.getBoolean(Prefs.SIXTY_FPS, true)) 60 else 30,
                glassEnabled = prefs.getBoolean(Prefs.GLASS, true),
                glowEnabled = prefs.getBoolean(Prefs.GLOW, true)
            )
        }
    }
}
