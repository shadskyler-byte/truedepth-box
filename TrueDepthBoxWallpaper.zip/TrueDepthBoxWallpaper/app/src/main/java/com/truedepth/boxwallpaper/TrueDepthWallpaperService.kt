package com.truedepth.boxwallpaper

import android.content.Context
import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.Surface
import android.view.WindowManager
import com.truedepth.boxwallpaper.gl.RenderThread
import com.truedepth.boxwallpaper.gl.RendererConfig
import kotlin.math.PI

class TrueDepthWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = TrueDepthEngine()

    inner class TrueDepthEngine : Engine(), SensorEventListener,
        SharedPreferences.OnSharedPreferenceChangeListener {

        private val sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val prefs = getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        private val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        private val rotationSensor: Sensor? =
            sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
                ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        private var renderThread: RenderThread? = null
        private var visible = false

        private var baselineSet = false
        private var basePitch = 0f
        private var baseRoll = 0f
        private var lastTapMs = 0L

        private val rotationMatrix = FloatArray(9)
        private val adjustedMatrix = FloatArray(9)
        private val orientation = FloatArray(3)

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
            prefs.registerOnSharedPreferenceChangeListener(this)
        }

        override fun onDestroy() {
            visible = false
            unregisterSensors()
            renderThread?.shutdownAndWait()
            renderThread = null
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            super.onDestroy()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            renderThread?.shutdownAndWait()
            renderThread = RenderThread(holder, applicationContext, RendererConfig.from(prefs)).also {
                it.isVisible = visible
                it.start()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            renderThread?.requestResize(width, height)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            renderThread?.shutdownAndWait()
            renderThread = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            renderThread?.isVisible = isVisible
            if (isVisible) {
                baselineSet = false
                registerSensors()
            } else {
                unregisterSensors()
            }
        }

        override fun onOffsetsChanged(
            xOffset: Float,
            yOffset: Float,
            xOffsetStep: Float,
            yOffsetStep: Float,
            xPixelOffset: Int,
            yPixelOffset: Int
        ) {
            val normalized = ((xOffset - 0.5f) * 2f).coerceIn(-1f, 1f)
            renderThread?.setLauncherOffset(normalized)
        }

        override fun onTouchEvent(event: MotionEvent) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                val now = SystemClock.uptimeMillis()
                if (now - lastTapMs in 40L..330L) {
                    baselineSet = false
                    renderThread?.pulseRecenter()
                    lastTapMs = 0L
                } else {
                    lastTapMs = now
                }
            }
            super.onTouchEvent(event)
        }

        override fun onSensorChanged(event: SensorEvent) {
            if (!visible || event.sensor.type != rotationSensor?.type) return

            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            @Suppress("DEPRECATION")
            val rotation = windowManager.defaultDisplay.rotation
            val (xAxis, yAxis) = when (rotation) {
                Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
                Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
                Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
                else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
            }
            SensorManager.remapCoordinateSystem(rotationMatrix, xAxis, yAxis, adjustedMatrix)
            SensorManager.getOrientation(adjustedMatrix, orientation)

            val pitch = orientation[1]
            val roll = orientation[2]

            if (!baselineSet) {
                basePitch = pitch
                baseRoll = roll
                baselineSet = true
                renderThread?.setTilt(0f, 0f)
                return
            }

            val pitchDelta = angleDelta(pitch, basePitch)
            val rollDelta = angleDelta(roll, baseRoll)

            // Roughly 18 degrees of phone tilt reaches full configured camera travel.
            val fullScale = Math.toRadians(18.0).toFloat()
            val x = (-rollDelta / fullScale).coerceIn(-1.35f, 1.35f)
            val y = (pitchDelta / fullScale).coerceIn(-1.35f, 1.35f)
            renderThread?.setTilt(x, y)
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

        override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
            renderThread?.setConfig(RendererConfig.from(prefs))
        }

        private fun registerSensors() {
            rotationSensor?.let {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
            }
        }

        private fun unregisterSensors() {
            sensorManager.unregisterListener(this)
        }

        private fun angleDelta(value: Float, base: Float): Float {
            var delta = value - base
            val pi = PI.toFloat()
            val twoPi = (PI * 2.0).toFloat()
            while (delta > pi) delta -= twoPi
            while (delta < -pi) delta += twoPi
            return delta
        }
    }
}
