package com.truedepth.boxwallpaper.gl

import android.content.Context
import android.opengl.GLES30
import android.opengl.Matrix
import kotlin.math.acos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sqrt

internal class SceneRenderer(@Suppress("UNUSED_PARAMETER") context: Context) {

    private val program = SceneProgram()
    private val cube = GpuMesh(Geometry.cube())
    private val sphere = GpuMesh(Geometry.sphere())
    private val cylinder = GpuMesh(Geometry.cylinder())
    private val quad = GpuMesh(Geometry.quad())

    private val view = FloatArray(16)
    private val proj = FloatArray(16)
    private val model = FloatArray(16)

    private var width = 1
    private var height = 1
    private var aspect = 1f

    private var targetTiltX = 0f
    private var targetTiltY = 0f
    private var smoothedTiltX = 0f
    private var smoothedTiltY = 0f
    private var launcherOffset = 0f
    private var config = RendererConfig(1f, 0.16f, 1f, 60, true, true)
    private var timeSeconds = 0f

    private val cameraPos = FloatArray(3)
    private val lightPos = floatArrayOf(0f, 0.9f, -0.8f)

    fun onSurfaceCreated() {
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glClearColor(0.018f, 0.022f, 0.028f, 1f)

        program.create()
        cube.upload()
        sphere.upload()
        cylinder.upload()
        quad.upload()
    }

    fun onSurfaceChanged(width: Int, height: Int) {
        this.width = width.coerceAtLeast(1)
        this.height = height.coerceAtLeast(1)
        aspect = this.width.toFloat() / this.height.toFloat()
        GLES30.glViewport(0, 0, this.width, this.height)
    }

    fun setInput(
        tiltX: Float,
        tiltY: Float,
        launcherOffset: Float,
        config: RendererConfig,
        recenter: Boolean
    ) {
        targetTiltX = tiltX
        targetTiltY = tiltY
        this.launcherOffset = launcherOffset
        this.config = config
        if (recenter) {
            smoothedTiltX = 0f
            smoothedTiltY = 0f
        }
    }

    fun drawFrame(dt: Float) {
        timeSeconds += dt

        val smoothing = config.smoothingSeconds.coerceAtLeast(0.015f)
        val alpha = 1f - exp((-dt / smoothing).toDouble()).toFloat()
        smoothedTiltX += (targetTiltX - smoothedTiltX) * alpha
        smoothedTiltY += (targetTiltY - smoothedTiltY) * alpha

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)

        // Screen plane: z=0. Camera sits in front of it. The asymmetric frustum keeps
        // the front opening visually locked to the physical display while the view point moves.
        val screenHalfH = 1.0f
        val screenHalfW = screenHalfH * aspect
        val openingHalfH = 0.88f
        val openingHalfW = screenHalfW * 0.88f

        val eyeZ = 1.68f
        val maxCameraX = openingHalfW * 0.42f
        val maxCameraY = openingHalfH * 0.28f
        val camX = (
            smoothedTiltX * maxCameraX * config.motionStrength +
                launcherOffset * openingHalfW * 0.07f
            ).coerceIn(-openingHalfW * 0.48f, openingHalfW * 0.48f)
        val camY = (smoothedTiltY * maxCameraY * config.motionStrength)
            .coerceIn(-openingHalfH * 0.34f, openingHalfH * 0.34f)

        cameraPos[0] = camX
        cameraPos[1] = camY
        cameraPos[2] = eyeZ

        Matrix.setIdentityM(view, 0)
        Matrix.translateM(view, 0, -camX, -camY, -eyeZ)

        val near = 0.08f
        val far = 18f
        val left = (-screenHalfW - camX) * near / eyeZ
        val right = (screenHalfW - camX) * near / eyeZ
        val bottom = (-screenHalfH - camY) * near / eyeZ
        val top = (screenHalfH - camY) * near / eyeZ
        Matrix.frustumM(proj, 0, left, right, bottom, top, near, far)

        lightPos[0] = camX * 0.22f
        lightPos[1] = openingHalfH * 0.66f
        lightPos[2] = -0.55f

        val depth = 4.15f * config.boxDepthScale
        drawRoom(openingHalfW, openingHalfH, depth)

        // Soft contact shadow: actual 3D geometry, flattened just above the floor.
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        drawSphere(
            0f,
            -openingHalfH + 0.018f,
            -depth * 0.57f,
            openingHalfW * 0.43f,
            0.018f,
            0.31f,
            color(0.015f, 0.018f, 0.02f, 0.35f)
        )
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)

        val widthScale = if (openingHalfW < 0.64f) (openingHalfW / 0.64f) else 1f
        val subjectScale = min(1.03f, widthScale.coerceAtLeast(0.72f))
        drawHuman(
            x = 0f,
            floorY = -openingHalfH + 0.025f,
            z = -depth * 0.57f,
            scale = subjectScale
        )

        drawFrontFrame(openingHalfW, openingHalfH)

        if (config.glassEnabled) {
            GLES30.glEnable(GLES30.GL_BLEND)
            GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
            GLES30.glDepthMask(false)
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, 0f, 0f, -0.018f)
            Matrix.scaleM(model, 0, openingHalfW * 2f, openingHalfH * 2f, 1f)
            program.draw(
                quad,
                model,
                view,
                proj,
                color(0.50f, 0.79f, 0.83f, 0.025f),
                lightPos,
                cameraPos,
                emissive = 0f,
                glass = true,
                timeSeconds = timeSeconds
            )
            GLES30.glDepthMask(true)
            GLES30.glDisable(GLES30.GL_BLEND)
        }
    }

    private fun drawRoom(halfW: Float, halfH: Float, depth: Float) {
        val wallT = 0.055f
        val frontZ = -0.10f
        val centerZ = -(depth + 0.10f) * 0.5f
        val wallLength = depth - 0.10f

        // Slightly different wall tones give the eye additional perspective cues.
        val leftWall = color(0.43f, 0.62f, 0.62f, 1f)
        val rightWall = color(0.49f, 0.69f, 0.68f, 1f)
        val floor = color(0.47f, 0.66f, 0.65f, 1f)
        val ceiling = color(0.38f, 0.56f, 0.57f, 1f)
        val back = color(0.58f, 0.82f, 0.79f, 1f)

        drawCube(-halfW - wallT * 0.5f, 0f, centerZ, wallT, halfH * 2f, wallLength, leftWall)
        drawCube(halfW + wallT * 0.5f, 0f, centerZ, wallT, halfH * 2f, wallLength, rightWall)
        drawCube(0f, -halfH - wallT * 0.5f, centerZ, halfW * 2f + wallT * 2f, wallT, wallLength, floor)
        drawCube(0f, halfH + wallT * 0.5f, centerZ, halfW * 2f + wallT * 2f, wallT, wallLength, ceiling)
        drawCube(0f, 0f, -depth - wallT * 0.5f, halfW * 2f + wallT * 2f, halfH * 2f, wallT, back)

        // A shallow illuminated rear panel makes depth readable without needing image layers.
        drawCube(
            0f,
            0f,
            -depth + 0.035f,
            halfW * 1.73f,
            halfH * 1.72f,
            0.025f,
            color(0.36f, 0.78f, 0.73f, 1f),
            emissive = 0.16f
        )

        if (config.glowEnabled) {
            val glow = color(0.20f, 0.92f, 0.82f, 1f)
            val g = 0.020f
            val z = -depth + 0.075f
            drawCube(-halfW * 0.86f, 0f, z, g, halfH * 1.68f, g, glow, emissive = 1.65f)
            drawCube(halfW * 0.86f, 0f, z, g, halfH * 1.68f, g, glow, emissive = 1.65f)
            drawCube(0f, halfH * 0.83f, z, halfW * 1.72f, g, g, glow, emissive = 1.65f)
            drawCube(0f, -halfH * 0.83f, z, halfW * 1.72f, g, g, glow, emissive = 1.65f)
        }

        // Tiny threshold at the front strengthens the sense of a physical cavity.
        drawCube(0f, -halfH + 0.025f, frontZ, halfW * 1.95f, 0.05f, 0.16f, color(0.18f, 0.22f, 0.24f, 1f))
    }

    private fun drawFrontFrame(halfW: Float, halfH: Float) {
        val frameT = 0.075f
        val frameDepth = 0.12f
        val frameColor = color(0.055f, 0.065f, 0.072f, 1f)
        val z = -0.035f
        drawCube(-halfW - frameT * 0.5f, 0f, z, frameT, halfH * 2f + frameT * 2f, frameDepth, frameColor)
        drawCube(halfW + frameT * 0.5f, 0f, z, frameT, halfH * 2f + frameT * 2f, frameDepth, frameColor)
        drawCube(0f, halfH + frameT * 0.5f, z, halfW * 2f + frameT * 2f, frameT, frameDepth, frameColor)
        drawCube(0f, -halfH - frameT * 0.5f, z, halfW * 2f + frameT * 2f, frameT, frameDepth, frameColor)
    }

    private fun drawHuman(x: Float, floorY: Float, z: Float, scale: Float) {
        val skin = color(0.76f, 0.58f, 0.46f, 1f)
        val shirt = color(0.23f, 0.34f, 0.25f, 1f)
        val jeans = color(0.12f, 0.27f, 0.39f, 1f)
        val shoes = color(0.09f, 0.11f, 0.12f, 1f)
        val hair = color(0.045f, 0.040f, 0.038f, 1f)
        val badge = color(0.68f, 0.82f, 0.84f, 1f)

        fun px(v: Float) = x + v * scale
        fun py(v: Float) = floorY + v * scale
        fun pz(v: Float) = z + v * scale

        // Legs and shoes.
        drawCylinderBetween(px(-0.13f), py(0.13f), pz(0f), px(-0.12f), py(0.62f), pz(0f), 0.10f * scale, jeans)
        drawCylinderBetween(px(0.13f), py(0.13f), pz(0f), px(0.12f), py(0.62f), pz(0f), 0.10f * scale, jeans)
        drawCube(px(-0.13f), py(0.07f), pz(0.035f), 0.23f * scale, 0.11f * scale, 0.31f * scale, shoes)
        drawCube(px(0.13f), py(0.07f), pz(0.035f), 0.23f * scale, 0.11f * scale, 0.31f * scale, shoes)

        // Pelvis and torso have real volume, so side surfaces appear as the camera moves.
        drawCube(px(0f), py(0.69f), pz(0f), 0.45f * scale, 0.24f * scale, 0.26f * scale, jeans)
        drawCube(px(0f), py(0.99f), pz(0f), 0.51f * scale, 0.54f * scale, 0.29f * scale, shirt)

        // Neck and head.
        drawCylinderBetween(px(0f), py(1.25f), pz(0f), px(0f), py(1.34f), pz(0f), 0.075f * scale, skin)
        drawSphere(px(0f), py(1.47f), pz(0f), 0.31f * scale, 0.36f * scale, 0.30f * scale, skin)
        drawSphere(px(0f), py(1.58f), pz(-0.015f), 0.30f * scale, 0.16f * scale, 0.29f * scale, hair)

        // Raised arm.
        drawCylinderBetween(px(-0.27f), py(1.15f), pz(0f), px(-0.39f), py(1.37f), pz(0.02f), 0.072f * scale, shirt)
        drawCylinderBetween(px(-0.39f), py(1.37f), pz(0.02f), px(-0.37f), py(1.67f), pz(0.02f), 0.062f * scale, skin)
        drawSphere(px(-0.37f), py(1.73f), pz(0.02f), 0.14f * scale, 0.17f * scale, 0.10f * scale, skin)

        // Relaxed arm.
        drawCylinderBetween(px(0.27f), py(1.15f), pz(0f), px(0.34f), py(0.91f), pz(0.01f), 0.075f * scale, shirt)
        drawCylinderBetween(px(0.34f), py(0.91f), pz(0.01f), px(0.35f), py(0.73f), pz(0.015f), 0.062f * scale, skin)
        drawSphere(px(0.35f), py(0.68f), pz(0.015f), 0.12f * scale, 0.15f * scale, 0.10f * scale, skin)

        // Lanyard and badge are 3D strips rather than billboarded image layers.
        drawCylinderBetween(px(-0.075f), py(1.19f), pz(0.16f), px(-0.035f), py(0.98f), pz(0.17f), 0.012f * scale, badge, emissive = 0.05f)
        drawCylinderBetween(px(0.075f), py(1.19f), pz(0.16f), px(0.035f), py(0.98f), pz(0.17f), 0.012f * scale, badge, emissive = 0.05f)
        drawCube(px(0f), py(0.91f), pz(0.19f), 0.17f * scale, 0.17f * scale, 0.025f * scale, badge, emissive = 0.08f)
    }

    private fun drawCube(
        x: Float,
        y: Float,
        z: Float,
        sx: Float,
        sy: Float,
        sz: Float,
        c: FloatArray,
        emissive: Float = 0f
    ) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.scaleM(model, 0, sx, sy, sz)
        draw(cube, c, emissive, false)
    }

    private fun drawSphere(
        x: Float,
        y: Float,
        z: Float,
        sx: Float,
        sy: Float,
        sz: Float,
        c: FloatArray,
        emissive: Float = 0f
    ) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.scaleM(model, 0, sx, sy, sz)
        draw(sphere, c, emissive, false)
    }

    private fun drawCylinderBetween(
        ax: Float,
        ay: Float,
        az: Float,
        bx: Float,
        by: Float,
        bz: Float,
        radius: Float,
        c: FloatArray,
        emissive: Float = 0f
    ) {
        val dx = bx - ax
        val dy = by - ay
        val dz = bz - az
        val length = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(0.0001f)
        val vx = dx / length
        val vy = dy / length
        val vz = dz / length

        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, (ax + bx) * 0.5f, (ay + by) * 0.5f, (az + bz) * 0.5f)

        val dot = vy.coerceIn(-1f, 1f)
        val angle = Math.toDegrees(acos(dot).toDouble()).toFloat()
        var rx = -vz
        var ry = 0f
        var rz = vx
        val axisLen = sqrt(rx * rx + ry * ry + rz * rz)
        if (axisLen > 0.0001f) {
            rx /= axisLen; ry /= axisLen; rz /= axisLen
            Matrix.rotateM(model, 0, angle, rx, ry, rz)
        } else if (vy < 0f) {
            Matrix.rotateM(model, 0, 180f, 1f, 0f, 0f)
        }
        Matrix.scaleM(model, 0, radius * 2f, length, radius * 2f)
        draw(cylinder, c, emissive, false)
    }

    private fun draw(mesh: GpuMesh, c: FloatArray, emissive: Float, glass: Boolean) {
        program.draw(
            mesh,
            model,
            view,
            proj,
            c,
            lightPos,
            cameraPos,
            emissive,
            glass,
            timeSeconds
        )
    }

    fun release() {
        quad.release()
        cylinder.release()
        sphere.release()
        cube.release()
        program.release()
    }

    private fun color(r: Float, g: Float, b: Float, a: Float) = floatArrayOf(r, g, b, a)
}
