package com.truedepth.boxwallpaper.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

internal data class MeshData(
    val vertices: FloatArray, // interleaved: position xyz, normal xyz
    val indices: IntArray
)

internal class GpuMesh(private val data: MeshData) {
    private var vao = 0
    private var vbo = 0
    private var ebo = 0
    private var indexCount = 0

    fun upload() {
        if (vao != 0) return
        val vaos = IntArray(1)
        val vbos = IntArray(2)
        GLES30.glGenVertexArrays(1, vaos, 0)
        GLES30.glGenBuffers(2, vbos, 0)
        vao = vaos[0]
        vbo = vbos[0]
        ebo = vbos[1]
        indexCount = data.indices.size

        val vertexBuffer = ByteBuffer.allocateDirect(data.vertices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply { put(data.vertices); position(0) }
        val indexBuffer = ByteBuffer.allocateDirect(data.indices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asIntBuffer()
            .apply { put(data.indices); position(0) }

        GLES30.glBindVertexArray(vao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            data.vertices.size * 4,
            vertexBuffer,
            GLES30.GL_STATIC_DRAW
        )
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ebo)
        GLES30.glBufferData(
            GLES30.GL_ELEMENT_ARRAY_BUFFER,
            data.indices.size * 4,
            indexBuffer,
            GLES30.GL_STATIC_DRAW
        )

        val stride = 6 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, stride, 3 * 4)

        GLES30.glBindVertexArray(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    fun draw() {
        if (vao == 0 || indexCount == 0) return
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, indexCount, GLES30.GL_UNSIGNED_INT, 0)
        GLES30.glBindVertexArray(0)
    }

    fun release() {
        if (vao != 0) GLES30.glDeleteVertexArrays(1, intArrayOf(vao), 0)
        if (vbo != 0 || ebo != 0) GLES30.glDeleteBuffers(2, intArrayOf(vbo, ebo), 0)
        vao = 0
        vbo = 0
        ebo = 0
        indexCount = 0
    }
}
