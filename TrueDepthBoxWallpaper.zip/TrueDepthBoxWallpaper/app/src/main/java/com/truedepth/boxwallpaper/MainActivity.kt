package com.truedepth.boxwallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences(Prefs.NAME, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(244, 245, 247)
        window.navigationBarColor = Color.rgb(244, 245, 247)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(28))
            setBackgroundColor(Color.rgb(244, 245, 247))
        }

        root.addView(TextView(this).apply {
            text = "TrueDepth Box"
            textSize = 28f
            setTextColor(Color.rgb(20, 23, 28))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "A real OpenGL 3D room. The phone tilt moves an off-axis virtual camera, so the walls, floor, frame and subject change perspective instead of sliding as flat layers."
            textSize = 16f
            setTextColor(Color.rgb(72, 77, 86))
            setPadding(0, dp(10), 0, dp(18))
        })

        addSeek(root, "3D motion strength", Prefs.MOTION_STRENGTH, 0, 160, 100) { value ->
            "${value}%"
        }
        addSeek(root, "Motion smoothing", Prefs.SMOOTHING, 0, 100, 42) { value ->
            if (value < 20) "Fast" else if (value < 65) "Balanced" else "Very smooth"
        }
        addSeek(root, "Box depth", Prefs.BOX_DEPTH, 60, 160, 100) { value ->
            "${value}%"
        }

        addSwitch(root, "60 FPS while visible", Prefs.SIXTY_FPS, true)
        addSwitch(root, "Front glass reflection", Prefs.GLASS, true)
        addSwitch(root, "Interior edge glow", Prefs.GLOW, true)

        val note = TextView(this).apply {
            text = "Tip: double-tap the live wallpaper to recenter the neutral viewing angle. Sensors and rendering pause when the wallpaper is not visible."
            textSize = 14f
            setTextColor(Color.rgb(86, 91, 100))
            setPadding(0, dp(18), 0, dp(16))
        }
        root.addView(note)

        val setButton = Button(this).apply {
            text = "Preview / Set Live Wallpaper"
            isAllCaps = false
            textSize = 17f
            minimumHeight = dp(52)
            setOnClickListener { openWallpaperPreview() }
        }
        root.addView(setButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val resetButton = Button(this).apply {
            text = "Reset tuning"
            isAllCaps = false
            setOnClickListener {
                prefs.edit().clear().apply()
                recreate()
            }
        }
        root.addView(resetButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }
        setContentView(scroll)
    }

    private fun addSeek(
        parent: LinearLayout,
        title: String,
        key: String,
        min: Int,
        max: Int,
        defaultValue: Int,
        formatter: (Int) -> String
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        val label = TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.rgb(28, 31, 36))
        }
        val valueLabel = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(82, 88, 98))
            gravity = Gravity.END
        }
        row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(valueLabel, LinearLayout.LayoutParams(dp(100), LinearLayout.LayoutParams.WRAP_CONTENT))
        parent.addView(row)

        val actual = prefs.getInt(key, defaultValue).coerceIn(min, max)
        valueLabel.text = formatter(actual)

        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = actual - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + min
                    valueLabel.text = formatter(value)
                    if (fromUser) prefs.edit().putInt(key, value).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        parent.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    @Suppress("DEPRECATION")
    private fun addSwitch(parent: LinearLayout, title: String, key: String, defaultValue: Boolean) {
        val toggle = Switch(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.rgb(28, 31, 36))
            isChecked = prefs.getBoolean(key, defaultValue)
            minimumHeight = dp(48)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
            }
        }
        parent.addView(toggle, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun openWallpaperPreview() {
        val component = ComponentName(this, TrueDepthWallpaperService::class.java)
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        }
        runCatching { startActivity(intent) }
            .onFailure {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

object Prefs {
    const val NAME = "true_depth_settings"
    const val MOTION_STRENGTH = "motion_strength"
    const val SMOOTHING = "smoothing"
    const val BOX_DEPTH = "box_depth"
    const val SIXTY_FPS = "sixty_fps"
    const val GLASS = "glass"
    const val GLOW = "glow"
}
