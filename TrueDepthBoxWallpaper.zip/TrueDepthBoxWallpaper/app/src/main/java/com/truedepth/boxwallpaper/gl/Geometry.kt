package com.truedepth.boxwallpaper.gl

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

internal object Geometry {

    fun cube(): MeshData {
        val v = floatArrayOf(
            // +Z
            -0.5f,-0.5f, 0.5f, 0f,0f,1f,
             0.5f,-0.5f, 0.5f, 0f,0f,1f,
             0.5f, 0.5f, 0.5f, 0f,0f,1f,
            -0.5f, 0.5f, 0.5f, 0f,0f,1f,
            // -Z
             0.5f,-0.5f,-0.5f, 0f,0f,-1f,
            -0.5f,-0.5f,-0.5f, 0f,0f,-1f,
            -0.5f, 0.5f,-0.5f, 0f,0f,-1f,
             0.5f, 0.5f,-0.5f, 0f,0f,-1f,
            // +X
             0.5f,-0.5f, 0.5f, 1f,0f,0f,
             0.5f,-0.5f,-0.5f, 1f,0f,0f,
             0.5f, 0.5f,-0.5f, 1f,0f,0f,
             0.5f, 0.5f, 0.5f, 1f,0f,0f,
            // -X
            -0.5f,-0.5f,-0.5f, -1f,0f,0f,
            -0.5f,-0.5f, 0.5f, -1f,0f,0f,
            -0.5f, 0.5f, 0.5f, -1f,0f,0f,
            -0.5f, 0.5f,-0.5f, -1f,0f,0f,
            // +Y
            -0.5f, 0.5f, 0.5f, 0f,1f,0f,
             0.5f, 0.5f, 0.5f, 0f,1f,0f,
             0.5f, 0.5f,-0.5f, 0f,1f,0f,
            -0.5f, 0.5f,-0.5f, 0f,1f,0f,
            // -Y
            -0.5f,-0.5f,-0.5f, 0f,-1f,0f,
             0.5f,-0.5f,-0.5f, 0f,-1f,0f,
             0.5f,-0.5f, 0.5f, 0f,-1f,0f,
            -0.5f,-0.5f, 0.5f, 0f,-1f,0f
        )
        val idx = IntArray(36)
        var p = 0
        for (face in 0 until 6) {
            val b = face * 4
            idx[p++] = b; idx[p++] = b + 1; idx[p++] = b + 2
            idx[p++] = b; idx[p++] = b + 2; idx[p++] = b + 3
        }
        return MeshData(v, idx)
    }

    fun sphere(latitudes: Int = 20, longitudes: Int = 28): MeshData {
        val verts = ArrayList<Float>((latitudes + 1) * (longitudes + 1) * 6)
        val indices = ArrayList<Int>(latitudes * longitudes * 6)
        for (lat in 0..latitudes) {
            val theta = PI * lat / latitudes
            val y = cos(theta).toFloat()
            val ring = sin(theta).toFloat()
            for (lon in 0..longitudes) {
                val phi = 2.0 * PI * lon / longitudes
                val x = ring * cos(phi).toFloat()
                val z = ring * sin(phi).toFloat()
                verts += x * 0.5f; verts += y * 0.5f; verts += z * 0.5f
                verts += x; verts += y; verts += z
            }
        }
        val row = longitudes + 1
        for (lat in 0 until latitudes) {
            for (lon in 0 until longitudes) {
                val a = lat * row + lon
                val b = a + row
                indices += a; indices += b; indices += a + 1
                indices += a + 1; indices += b; indices += b + 1
            }
        }
        return MeshData(verts.toFloatArray(), indices.toIntArray())
    }

    fun cylinder(segments: Int = 28): MeshData {
        val verts = ArrayList<Float>()
        val indices = ArrayList<Int>()

        // Side vertices: two rings, unit cylinder along Y, radius .5, height 1.
        for (i in 0..segments) {
            val a = 2.0 * PI * i / segments
            val x = cos(a).toFloat()
            val z = sin(a).toFloat()
            verts += x * 0.5f; verts += -0.5f; verts += z * 0.5f
            verts += x; verts += 0f; verts += z
            verts += x * 0.5f; verts += 0.5f; verts += z * 0.5f
            verts += x; verts += 0f; verts += z
        }
        for (i in 0 until segments) {
            val b = i * 2
            indices += b; indices += b + 1; indices += b + 2
            indices += b + 2; indices += b + 1; indices += b + 3
        }

        // Bottom cap.
        val bottomCenter = verts.size / 6
        verts += 0f; verts += -0.5f; verts += 0f
        verts += 0f; verts += -1f; verts += 0f
        val bottomStart = verts.size / 6
        for (i in 0..segments) {
            val a = 2.0 * PI * i / segments
            verts += (cos(a) * 0.5).toFloat(); verts += -0.5f; verts += (sin(a) * 0.5).toFloat()
            verts += 0f; verts += -1f; verts += 0f
        }
        for (i in 0 until segments) {
            indices += bottomCenter; indices += bottomStart + i + 1; indices += bottomStart + i
        }

        // Top cap.
        val topCenter = verts.size / 6
        verts += 0f; verts += 0.5f; verts += 0f
        verts += 0f; verts += 1f; verts += 0f
        val topStart = verts.size / 6
        for (i in 0..segments) {
            val a = 2.0 * PI * i / segments
            verts += (cos(a) * 0.5).toFloat(); verts += 0.5f; verts += (sin(a) * 0.5).toFloat()
            verts += 0f; verts += 1f; verts += 0f
        }
        for (i in 0 until segments) {
            indices += topCenter; indices += topStart + i; indices += topStart + i + 1
        }

        return MeshData(verts.toFloatArray(), indices.toIntArray())
    }

    fun quad(): MeshData {
        val vertices = floatArrayOf(
            -0.5f,-0.5f,0f, 0f,0f,1f,
             0.5f,-0.5f,0f, 0f,0f,1f,
             0.5f, 0.5f,0f, 0f,0f,1f,
            -0.5f, 0.5f,0f, 0f,0f,1f
        )
        return MeshData(vertices, intArrayOf(0,1,2, 0,2,3))
    }
}
