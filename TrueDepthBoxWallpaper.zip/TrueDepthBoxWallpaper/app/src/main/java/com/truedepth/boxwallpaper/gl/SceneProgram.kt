package com.truedepth.boxwallpaper.gl

import android.opengl.GLES30

internal class SceneProgram {
    private var program = 0

    private var uModel = -1
    private var uView = -1
    private var uProj = -1
    private var uBaseColor = -1
    private var uLightPos = -1
    private var uCameraPos = -1
    private var uEmissive = -1
    private var uGlass = -1
    private var uTime = -1

    fun create() {
        val vertex = compile(GLES30.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fragment = compile(GLES30.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        program = GLES30.glCreateProgram()
        GLES30.glAttachShader(program, vertex)
        GLES30.glAttachShader(program, fragment)
        GLES30.glBindAttribLocation(program, 0, "aPosition")
        GLES30.glBindAttribLocation(program, 1, "aNormal")
        GLES30.glLinkProgram(program)
        val linked = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, linked, 0)
        if (linked[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(program)
            GLES30.glDeleteProgram(program)
            throw IllegalStateException("GL program link failed: $log")
        }
        GLES30.glDeleteShader(vertex)
        GLES30.glDeleteShader(fragment)

        uModel = GLES30.glGetUniformLocation(program, "uModel")
        uView = GLES30.glGetUniformLocation(program, "uView")
        uProj = GLES30.glGetUniformLocation(program, "uProj")
        uBaseColor = GLES30.glGetUniformLocation(program, "uBaseColor")
        uLightPos = GLES30.glGetUniformLocation(program, "uLightPos")
        uCameraPos = GLES30.glGetUniformLocation(program, "uCameraPos")
        uEmissive = GLES30.glGetUniformLocation(program, "uEmissive")
        uGlass = GLES30.glGetUniformLocation(program, "uGlass")
        uTime = GLES30.glGetUniformLocation(program, "uTime")
    }

    fun draw(
        mesh: GpuMesh,
        model: FloatArray,
        view: FloatArray,
        proj: FloatArray,
        color: FloatArray,
        lightPos: FloatArray,
        cameraPos: FloatArray,
        emissive: Float,
        glass: Boolean,
        timeSeconds: Float
    ) {
        GLES30.glUseProgram(program)
        GLES30.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES30.glUniformMatrix4fv(uView, 1, false, view, 0)
        GLES30.glUniformMatrix4fv(uProj, 1, false, proj, 0)
        GLES30.glUniform4fv(uBaseColor, 1, color, 0)
        GLES30.glUniform3fv(uLightPos, 1, lightPos, 0)
        GLES30.glUniform3fv(uCameraPos, 1, cameraPos, 0)
        GLES30.glUniform1f(uEmissive, emissive)
        GLES30.glUniform1i(uGlass, if (glass) 1 else 0)
        GLES30.glUniform1f(uTime, timeSeconds)
        mesh.draw()
    }

    fun release() {
        if (program != 0) GLES30.glDeleteProgram(program)
        program = 0
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(shader)
            GLES30.glDeleteShader(shader)
            throw IllegalStateException("GL shader compile failed: $log")
        }
        return shader
    }

    companion object {
        private const val VERTEX_SHADER = """
            #version 300 es
            precision highp float;
            layout(location=0) in vec3 aPosition;
            layout(location=1) in vec3 aNormal;

            uniform mat4 uModel;
            uniform mat4 uView;
            uniform mat4 uProj;

            out vec3 vWorldPos;
            out vec3 vNormal;

            void main() {
                vec4 world = uModel * vec4(aPosition, 1.0);
                vWorldPos = world.xyz;
                vNormal = normalize(mat3(uModel) * aNormal);
                gl_Position = uProj * uView * world;
            }
        """

        private const val FRAGMENT_SHADER = """
            #version 300 es
            precision highp float;

            in vec3 vWorldPos;
            in vec3 vNormal;

            uniform vec4 uBaseColor;
            uniform vec3 uLightPos;
            uniform vec3 uCameraPos;
            uniform float uEmissive;
            uniform int uGlass;
            uniform float uTime;

            out vec4 fragColor;

            void main() {
                vec3 N = normalize(vNormal);
                vec3 V = normalize(uCameraPos - vWorldPos);
                vec3 L = normalize(uLightPos - vWorldPos);
                vec3 H = normalize(L + V);

                float diffuse = max(dot(N, L), 0.0);
                float spec = pow(max(dot(N, H), 0.0), 40.0);

                if (uGlass == 1) {
                    float fresnel = pow(1.0 - clamp(abs(dot(N, V)), 0.0, 1.0), 2.2);
                    float sweepCoord = vWorldPos.x * 0.55 + vWorldPos.y * 0.18 + uTime * 0.035;
                    float sweep = pow(max(0.0, 1.0 - abs(fract(sweepCoord) - 0.5) * 14.0), 3.0);
                    vec3 glassColor = uBaseColor.rgb + vec3(0.22, 0.35, 0.42) * fresnel + vec3(0.20) * sweep;
                    float alpha = clamp(uBaseColor.a + fresnel * 0.11 + sweep * 0.035, 0.0, 0.24);
                    fragColor = vec4(glassColor, alpha);
                    return;
                }

                vec3 lit = uBaseColor.rgb * (0.23 + 0.72 * diffuse);
                lit += vec3(0.22) * spec;
                lit += uBaseColor.rgb * uEmissive;
                fragColor = vec4(lit, uBaseColor.a);
            }
        """
    }
}
