package com.truedepth.boxwallpaper.gl

import android.content.Context
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.GLES30
import android.view.SurfaceHolder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class RenderThread(
    private val holder: SurfaceHolder,
    context: Context,
    initialConfig: RendererConfig
) : Thread("TrueDepthGL") {

    @Volatile var isVisible: Boolean = false

    @Volatile private var running = true
    @Volatile private var targetTiltX = 0f
    @Volatile private var targetTiltY = 0f
    @Volatile private var launcherOffset = 0f
    @Volatile private var config = initialConfig
    @Volatile private var pendingWidth = 0
    @Volatile private var pendingHeight = 0
    private val recenterPulse = AtomicBoolean(false)

    private val renderer = SceneRenderer(context.applicationContext)

    private var eglDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface = EGL14.EGL_NO_SURFACE

    fun setTilt(x: Float, y: Float) {
        targetTiltX = x
        targetTiltY = y
    }

    fun setLauncherOffset(value: Float) {
        launcherOffset = value
    }

    fun setConfig(value: RendererConfig) {
        config = value
    }

    fun requestResize(width: Int, height: Int) {
        pendingWidth = width
        pendingHeight = height
    }

    fun pulseRecenter() {
        recenterPulse.set(true)
    }

    fun shutdownAndWait() {
        running = false
        interrupt()
        if (Thread.currentThread() !== this) {
            runCatching { join(1200) }
        }
    }

    override fun run() {
        try {
            initEgl()
            renderer.onSurfaceCreated()

            val frame = holder.surfaceFrame
            var width = max(1, if (pendingWidth > 0) pendingWidth else frame.width())
            var height = max(1, if (pendingHeight > 0) pendingHeight else frame.height())
            renderer.onSurfaceChanged(width, height)

            var lastNs = System.nanoTime()
            while (running) {
                if (!isVisible || !holder.surface.isValid) {
                    try {
                        sleep(120)
                    } catch (_: InterruptedException) {
                    }
                    lastNs = System.nanoTime()
                    continue
                }

                val w = pendingWidth
                val h = pendingHeight
                if (w > 0 && h > 0 && (w != width || h != height)) {
                    width = w
                    height = h
                    renderer.onSurfaceChanged(width, height)
                }

                val now = System.nanoTime()
                val dt = ((now - lastNs) / 1_000_000_000.0).toFloat().coerceIn(0f, 0.08f)
                lastNs = now

                val cfg = config
                renderer.setInput(targetTiltX, targetTiltY, launcherOffset, cfg, recenterPulse.getAndSet(false))
                renderer.drawFrame(dt)

                if (!EGL14.eglSwapBuffers(eglDisplay, eglSurface)) {
                    break
                }

                val frameBudgetNs = 1_000_000_000L / cfg.targetFps.coerceIn(24, 60)
                val spent = System.nanoTime() - now
                val sleepNs = frameBudgetNs - spent
                if (sleepNs > 1_000_000L) {
                    try {
                        val ms = sleepNs / 1_000_000L
                        val ns = (sleepNs % 1_000_000L).toInt()
                        Thread.sleep(ms, ns)
                    } catch (_: InterruptedException) {
                    }
                } else {
                    Thread.yield()
                }
            }
        } finally {
            renderer.release()
            releaseEgl()
        }
    }

    private fun initEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(eglDisplay != EGL14.EGL_NO_DISPLAY) { "Unable to get EGL display" }

        val version = IntArray(2)
        check(EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) { "Unable to initialize EGL" }

        val configAttribs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_DEPTH_SIZE, 24,
            EGL14.EGL_STENCIL_SIZE, 8,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
        val count = IntArray(1)
        check(EGL14.eglChooseConfig(eglDisplay, configAttribs, 0, configs, 0, 1, count, 0) && count[0] > 0) {
            "No suitable EGL config"
        }
        val eglConfig = configs[0] ?: error("EGL config missing")

        val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(
            eglDisplay,
            eglConfig,
            EGL14.EGL_NO_CONTEXT,
            contextAttribs,
            0
        )
        check(eglContext != EGL14.EGL_NO_CONTEXT) { "Unable to create GLES 3 context" }

        val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(
            eglDisplay,
            eglConfig,
            holder.surface,
            surfaceAttribs,
            0
        )
        check(eglSurface != EGL14.EGL_NO_SURFACE) { "Unable to create EGL window surface" }
        check(EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) { "Unable to make EGL current" }

        GLES30.glDisable(GLES30.GL_DITHER)
    }

    private fun releaseEgl() {
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(
                eglDisplay,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_CONTEXT
            )
            if (eglSurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, eglSurface)
            }
            if (eglContext != EGL14.EGL_NO_CONTEXT) {
                EGL14.eglDestroyContext(eglDisplay, eglContext)
            }
            EGL14.eglTerminate(eglDisplay)
        }
        eglSurface = EGL14.EGL_NO_SURFACE
        eglContext = EGL14.EGL_NO_CONTEXT
        eglDisplay = EGL14.EGL_NO_DISPLAY
    }
}
