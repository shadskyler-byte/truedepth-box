# TrueDepth Box Wallpaper

Android live wallpaper prototype that renders a **real 3D scene** with OpenGL ES 3.0. It does not slide 2D image layers.

## What is actually 3D

- A six-surface display box/cavity (left wall, right wall, floor, ceiling, back wall, front frame)
- A volumetric 3D human mannequin made from real geometry
- Dynamic perspective and occlusion from the depth buffer
- A transparent front-glass pass with angle-dependent reflection
- Interior emissive edge lights
- A contact shadow under the subject

## The important part: off-axis perspective

The front of the virtual box is treated as the phone's physical screen plane. Gyro tilt changes the virtual eye position. The renderer then builds an **asymmetric projection frustum** so the front opening remains visually attached to the display while the inside of the box changes perspective.

That is why moving the phone exposes more of one side wall, changes floor/ceiling perspective, and shifts the subject relative to the back wall instead of simply moving flat layers.

## Motion system

- Uses `TYPE_GAME_ROTATION_VECTOR` when available, then falls back to `TYPE_ROTATION_VECTOR`.
- Re-centers when the wallpaper becomes visible.
- Double-tap the live wallpaper to re-center manually.
- Motion is smoothed before it reaches the virtual camera.
- Rendering and sensors stop when the wallpaper is not visible.
- Launcher page offsets add a very small secondary camera displacement.

## Settings

The launcher activity exposes:

- 3D motion strength
- motion smoothing
- box depth
- 30 / 60 FPS choice
- front glass reflection toggle
- interior glow toggle

## Project requirements

- Android Studio with Android SDK 35 installed
- JDK 17
- OpenGL ES 3.0 capable Android phone
- Minimum Android 8.0 (API 26)

## Build

1. Open this folder in Android Studio.
2. Let Android Studio sync the Gradle project and install SDK 35 if prompted.
3. Build and run the `app` module.
4. Open **TrueDepth Box** on the phone.
5. Tap **Preview / Set Live Wallpaper**.
6. Tilt the phone left/right/up/down while looking at the box.

The project intentionally contains no machine-specific `local.properties` file.

## Current subject

The bundled subject is a generated 3D mannequin so the demo remains fully self-contained and unquestionably volumetric. It is not a billboard or a cut-out image.

For a photoreal person, the next asset should be an actual textured human mesh / scan (GLB, glTF, OBJ + texture, or another runtime-friendly 3D representation). A single front photograph cannot reveal genuinely unseen side geometry when the camera moves.

The renderer is already structured so the procedural `drawHuman()` can be replaced by a loaded 3D asset without changing the gyro camera, box, glass, projection, or wallpaper lifecycle.

## Main files

- `TrueDepthWallpaperService.kt` — Android wallpaper lifecycle, sensors, recentering
- `RenderThread.kt` — EGL/OpenGL render thread and visibility throttling
- `SceneRenderer.kt` — real 3D box, human geometry, off-axis camera
- `SceneProgram.kt` — GLES 3 shaders for lighting/glass
- `Geometry.kt` — cube, sphere, cylinder and quad mesh generation
- `MainActivity.kt` — tuning controls and live-wallpaper launcher

