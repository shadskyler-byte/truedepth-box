# Implementation notes

## Why this is not conventional parallax

Conventional live wallpapers usually calculate a 2D offset for several image layers. This project instead updates the camera position in a 3D coordinate system and re-projects actual meshes every frame.

For a virtual screen half-width `W`, screen half-height `H`, camera position `(cx, cy, eyeZ)` and near plane `n`, the projection is built as:

- left = `(-W - cx) * n / eyeZ`
- right = `(W - cx) * n / eyeZ`
- bottom = `(-H - cy) * n / eyeZ`
- top = `(H - cy) * n / eyeZ`

This is an off-axis frustum. It keeps the physical screen plane stable while objects behind it show viewpoint-dependent parallax and perspective.

## Power behavior

The wallpaper engine unregisters motion sensors and pauses rendering whenever Android reports the wallpaper as invisible. The user can also select 30 FPS.

## Foldables

The renderer rebuilds the viewport/projection whenever the wallpaper surface size changes. The virtual opening width is derived from the live aspect ratio, so it adapts to cover / inner display changes rather than relying on a fixed wallpaper bitmap size.

